
const PERFIL = {
    MANAGER: 'manager',
    VALIDADOR: 'validador',
    RESTRINGIDO: 'restringido'
}

module.exports = {
    PERFIL: PERFIL, //ROL DE TIPO ROL
    users: [
        { id: 1, nombre: 'Kyle', role: PERFIL.MANAGER } ,
        { id: 2, nombre: 'Sally', role: PERFIL.VALIDADOR },
        { id: 3, nombre: 'Joe', role: PERFIL.RESTRINGIDO }
    ],
    clientes: [
        { id: 1, nombre: "Kyle's info", userId:1 },
        { id: 2, nombre: "Sally's info", usersId: 2},
        { id: 3, nombre: "Joe's info", userId: 3}
    ]
}