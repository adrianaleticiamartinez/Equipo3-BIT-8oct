const express = require ('express');
const { users } = require('./data');
const app = express();
const { autenticacion } = require('./autenticacion');
const clienteRouter = require('./routes/cliente');

//para convertir csv a json
const csvtojson = require('csvtojson');
const fs = require('fs ');
const csvFilepath = 'db.csv'


//middleware
app.use(express.json());
app.use(setUser)
app.use('/clientes',clienteRouter)

app.get('/', (req, res) =>{
    const id = req.params.id;
    res.send(`Manager page ${id}`)
})

// app.get('/validador', (req, res) => {
//     res.send('validador page')
// })

// app.get('/restringido',(req, res) => {
//     res.send('vista restingida')
// })

//funcion que obtiene el usuario de la consulta actual
function setUser(req, res , next) {
    //toma el id de la consulta
    const userId = req.body.userId;
    // si la peticion busca un id y guarda el usuario en una variable 
    console.log(userId);
    if(userId){
        req.user = users.find(user => users.id === userId)
    }
    next()
}


app.listen(5000 ,() => console.log('escuchando en puerto 5000'));