const express = require('express');
const router = express.Router();
//carga la db
const {clientes} = require('../data')

router.get('/', (req, res) => {
    res.json(clientes)
})


function setCliente(req, res ,next) {
    const clienteId = parseInt(req.params.clienteId)
    req.cliente = clientes.find( project => project.id === clienteId)

    if(req.project === null) {
        res.status(404)
        return res.send('cliente no encontrado');
    }
    next()
}

module.exports = router;