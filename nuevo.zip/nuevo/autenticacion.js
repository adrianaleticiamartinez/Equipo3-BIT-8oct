
function autenticacion ( req, res, next) {
    
    if(req.user == null){
        rest(403)
        return res.sen('tienes que iniciar sesion')
    }
    next()
}

module.exports=( autenticacion)