from django.shortcuts import render
from rest_framework.views import APIView as API
from rest_framework.response import Response
from django.contrib.auth import authenticate
from rest_framework.authtoken.models import Token
import pandas as pd 

from .models import Users 
from .serializer import UserSerializer
from Clients.serializer import ClientsSerializer
from Clients.models import Clients

def getToken(headers):
    auth = headers['Authorization']
    start = False
    token = ''
    for i in auth:
        if i == " ":
            start = True
            continue
        if start:
            token += i
    return token




class MigrateCSV(API):
    def post(self,request):
        response = []
        _file = request.data.get("file")
        df=pd.read_csv(_file, sep=',',header=0,  na_filter= None)
        count = 0
        for i in df.values:
            count +=1
            print(count) 
            id = i[0]
            name = i[1]
            p_lname = i[2]
            m_lname = i[3]
            date = i[4]
            sex = i[5]
            segmento = i[6]
            nationality = i[7]
            rfc = i[8]
            tipo_id = i[9]
            numero_id = i[10]
            acount = i[11]
            email = i[12] if  i[12] else "---"
            data = {
                "id":id,
                "name":name,
                "p_lname":p_lname,
                "m_lname":m_lname,
                "date_b":date,
                "sex":sex,
                "segment":segmento,
                "nationality":nationality,
                "rfc":rfc,
                "numberid":tipo_id,
                "typeid":numero_id,
                "cuenta":acount,
                "email":email,
            }
            serializer = ClientsSerializer(data=data)
            
            if serializer.is_valid():
                print("v")
                serializer.save()  
            
        
        return Response("ok")



class UsersCRUD(API):
    def ast(self,value):
        name = ""
        count = 0
        for i in value:
            count +=1
            if count <= 3:
                name += i
            else :
                name += '*'
        return name

    def get(self, request):
        
        token = getToken(request.headers)
        
        if token == '':
            return Response([])
        else:
            user = Users.objects.filter(auth_token = token)
            if user:
                profile = int(user[0].profile)

                if profile == 0:
                    query = Clients.objects.all().values()
                    return Response(query)
                
                elif profile == 1:
                    list_ = [] 
                    query = list(Clients.objects.all())
                     
                    for i in query:
                        void = []
                        id = i.id
                        name = i.name
                        p_lname = self.ast(i.p_lname)
                        m_lname = self.ast(i.m_lname)
                        date_b = self.ast(i.date_b)
                        sex = i.sex
                        segment = i.segment
                        nationality = self.ast(i.nationality)
                        rfc = self.ast(i.rfc)
                        numberid = self.ast(i.numberid)
                        typeid = self.ast(i.typeid)
                        cuenta = i.cuenta
                        email = self.ast(i.email)
                        if email == "---":
                            void = ["email"]
                        list_.append({
                            "id":id,
                            "name":name,
                            "p_lname":p_lname,
                            "m_lname":m_lname,
                            "date_b":date_b,
                            "sex":sex,
                            "segment":segment,
                            "nationality":nationality,
                            "rfc":rfc,
                            "numberid":numberid,
                            "typeid":typeid,
                            "cuenta":cuenta,
                            "email":email,
                            "vacios":void
                        })
                    return Response(list_)
                elif profile == 2:
                    query = Clients.objects.all().values('id','name','sex','segment','cuenta')
                    return Response(query)

        #            print("It's validator")
        #        elif profile == 2:
        #            print("It's restringido")
#
        #username = request.GET.get('username')
        #email = request.GET.get('email')
        #if username or email:
        #    data = {
        #        "username" : username,
        #        "email"    : email
        #    }
        #    return Response(data)
        #else:
        #    users_list = Users.objects.all().values('email','username','profile')
        #    users_list = list(users_list)
        #    return Response(users_list)


    def post(self, request):
        data    = request.data
        exist_emial = Users.objects.filter(email = data['email'])
        # Revisa si ya existe un usuario con ese email   
        if(exist_emial):
            return Response([
                False,
                {
                    "username":[
                        "Ya existe un usuario con ese email"
                    ],
                }
            ])
        user_serializer = UserSerializer( data = data)
        if user_serializer.is_valid():
            user_serializer.save()
            return Response({
                "ok":True,
                "data":user_serializer.data
            })
            
        else:
            return Response({
                "ok":False,
                "data":user_serializer.errors
            })

            


class Login(API):
    permission_classes = ()
    def post(self, request,):
        username = request.data.get("username")
        password = request.data.get("password")
        # Login por email 
        try:
            user = Users.objects.get(email=username)
            if user.check_password(password):
                data = self.getToken(user)
                return Response(data)
        except:
            pass
        
        # Login por nombre de usuario
        user = authenticate(username=username, password=password)
        if user:
            data = self.getToken(user)
            return Response(data)
        else:
            return Response({"ok":False, "token":None, "id":None,  "username":None, "email":None})
    
    def getToken(self, user):
        # Si el usuario no tiene un token, asignarle uno 
        if not(user.auth_token.key):
            Token.objects.create(user=user)
        print(user)
        return {"ok":True, "token": user.auth_token.key, "id":user.id, "username":user.username, "email":user.email}

