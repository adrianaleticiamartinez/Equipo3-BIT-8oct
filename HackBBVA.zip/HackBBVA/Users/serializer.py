#from django.contrib.auth.models import User
from Users.models import Users
from rest_framework import serializers
from django.contrib.auth.hashers import make_password
from rest_framework.authtoken.models import Token



class UserSerializer(serializers.ModelSerializer):
    class Meta:
        model = Users
        fields = ("username","password","email","profile") # '__all__'
        extra_kwargs = {'password': {'write_only':True}}   
        #read_only_fields = ("password",)
    
    def create(self, validated_data):
        

        user = Users(
            email    = validated_data['email'],
            username = validated_data['username'],
            profile  = validated_data['profile'],
        )

        user.set_password(validated_data['password'])
        user.save()
        # Asignamos un token al nuevo usuario 
        Token.objects.create(user = user)
        return user