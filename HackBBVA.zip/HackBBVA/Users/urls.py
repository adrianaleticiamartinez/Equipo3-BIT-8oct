from django.urls import path 
from rest_framework.routers import DefaultRouter
from .views import *

urlpatterns = [
    path('', UsersCRUD.as_view(),name='user_crud'),
    path('migrate/', MigrateCSV.as_view(),name='user_migrate_csv'),
    path('login/', Login.as_view(),name='user_login'),
]


from django.contrib import admin
#Custom titles for admin
admin.site.site_header = "BIT BBVA"
admin.site.index_title = "Panel de administración"
admin.site.site_title  = "BIT BBVA"