from django.db import models

class Clients(models.Model):
    id       = models.CharField(max_length=50, unique= True, null = False, verbose_name= "id", primary_key=True)
    name     = models.CharField(max_length=50, unique= False, null = True, verbose_name= "Nombre completo")
    p_lname  = models.CharField(max_length=50, unique= False,  null = True, verbose_name= "Apellido")
    m_lname  = models.CharField(max_length=50, unique= False,  null = True, verbose_name= "Apellido ")
    date_b   = models.CharField(max_length=50, unique= False,  null = True, verbose_name= "Fecha")
    sex      = models.CharField(max_length=50,  unique= False,  null = True, verbose_name= "Sexo")
    segment     = models.CharField(max_length=50,  unique= False,  null = True, verbose_name= "Segmento")
    nationality     = models.CharField(max_length=50,  unique= False,  null = True, verbose_name= "Nacionalidad")
    rfc = models.CharField(max_length=50,  unique= False,  null = True, verbose_name= "RFC")
    numberid = models.CharField(max_length=50,  unique= False,  null = True, verbose_name= "Numero id")
    typeid =  models.CharField(max_length=50,  unique= False,  null = True, verbose_name= "Tipo de id") 
    cuenta = models.CharField(max_length=50,  unique= False,  null = True, verbose_name= "Cuenta")
    email = models.CharField(max_length=50,  unique= False,  null = True, verbose_name= "Email")

   
    class Meta:
        verbose_name = 'Cliente'
        verbose_name_plural = 'Clientes'
    
    def __str__(self):
        return self.name